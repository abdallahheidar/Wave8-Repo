#include "Tmu_cfg.h"




/******Initialize the structure of the TMU_cfg struct ***********/

TMU_ConfigType ConfigPtr  = {TMU_TIMER_CH0,Res1};
TMU_ConfigType ConfigPtr1 = {TMU_TIMER_CH1,Res1};
TMU_ConfigType ConfigPtr2 = {TMU_TIMER_CH2,Res1};
TMU_ConfigType ConfigPtr3 = {5,Res1};
//TMU_ConfigType ConfigPtr4;



